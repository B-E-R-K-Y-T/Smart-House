# ======================================================================================================================

# Author: BERKYT

# ======================================================================================================================

import json


def read_json_line():
    pass


def create_path(list_path: list):
    import sys

    main_directory = str(__file__)[:str(__file__).rfind('/')]

    for sub_path in list_path:
        sys.path.append(main_directory + '/' + sub_path)


with open('code.json', 'r') as js_f:
    dict_json = json.load(js_f)

for file in dict_json.keys():
    with open(file, 'w') as f:
        f.write(dict_json[file])
